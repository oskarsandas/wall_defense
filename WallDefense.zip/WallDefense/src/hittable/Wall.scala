package hittable

// each WallBlock has a Wall object that extends Hittable
class Wall(hp : Int) extends Hittable(hp) {
  
}

