package hittable
import block._
import game._

/* represents a villain in the game
 * it can hit Walls and BarbWires
 * on every hit, it takes this.damage from the object that is hit
 * hitRate tells how many hits / s it can give
 */

class BadGuy (val damage: Int, val rewardIfKilled: Int, val hitRate: Double, val speed: Int, hp: Int) extends Hittable(hp) {
  private var currentX = 0.0
  private var currentY = 0.0
  // returns the direction in which it is moving in
  private var currentDir: Dir = S
  
  /* returns the path which it follows
   * when the BadGuy is spawned it gets a path
   */
  private var path: Option[Path] = None
  
  def x = currentX
  def y = currentY
  def dir = currentDir
  
  // changes the x coordinate to v
  def setX(v: Double) = {
    currentX = v
  }
  
  // changes the y coordinate to v
  def setY(v: Double) = {
    currentY = v
  }
  
  // changes the direction to d
  def setDir(d: Dir) = {
    currentDir = d
  }
  
  /* gives the BadGuy a path 
   *  ,sets its x and y coordinates to the coordinates of the first point on the path
   *  and changes the direction to the direction given by the first point of the path
   */
  def setPath(p: Path) = {
    path = Some(p)
    setX(nextPoint._1)
    setY(nextPoint._2)
    setDir(nextPoint._3)
  }
  
  // returns the next point on the path
  def nextPoint = {
    path.getOrElse(throw new NoSuchElementException("no path assigned to villain")).nextPoint
  }
  
  /* reads the current point on the path I.e. changes to the next point
   * is called when the BadGuy has reached the current this.nextPoint
   */
  def pointRead = {
    path.getOrElse(throw new NoSuchElementException("no path assigned to villain")).pointRead
  }
  
  // is called if the whole path is read I.e. all points are read
  def pathRead = {
    path.getOrElse(throw new NoSuchElementException("no path assigned to villain")).read
  }
  
  // returns the interval at which hits are given
  private var interval = 1 / hitRate
  private var tmr = interval
  
  
  /* takes the interval between this and the previous frame
   * returns true every this.interval seconds
   * if it returns true, the wall or barbWire in front of this BadGuy will be hit 
   */
  def hitTimer(t: Double) = {
    tmr -= t
    if(0 >= tmr) {
      tmr = interval
      true
    } else false
  }
  
  /* hits the given block(b)
   * if b is a Road block with a barbWire, the barbWire will be hit
   * if b is a WallBlock, the barbWire on the wall will be hit, and if there is no barbWire on the wall, the wall will be hit
   */
  def hit(b: Block) = {
    b.name match{
      case "Road" => b.asInstanceOf[Road].barbWire.get.takeHp(damage)
      case "Wall" => {
        val wall = b.asInstanceOf[WallBlock]
        if(wall.hasBarbWire) {
          wall.barbWire.get.takeHp(damage)
        } else {
          wall.wall.takeHp(damage)
        }
      }
    }
  }
  
  
}
