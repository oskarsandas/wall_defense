package hittable

/* represents a wave of villains
 * villains : the villains that belong to this wave
 * timeBetween : the interval at which a new villain will spawn
 * if timeBetween = 1.0 => every 1 seconds a new randomly selected (from villains) BadGuy spawns
 */

class Wave(val villains: Array[BadGuy], val timeBetween: Double) {
  
  val bads = villains.toBuffer
  val r = new util.Random(System.currentTimeMillis.toInt)
  private var tmr = timeBetween
  
  // counter : how many BadGuys have spawned
  private var counter = 0
  
  /* timer : takes the time difference between this and the previous frame
   * if it has been timeBetween seconds, since the last BadGuy spawned and bads still contains BadGuys, timer returns Some(BadGuy)
   */
  def timer(t: Double): Option[BadGuy] = {
    tmr -= t
    if(0 >= tmr) {
      tmr = timeBetween
      val i = r.nextInt(bads.size)
      val b = bads(i)
      bads.remove(i)
      counter += 1
      Some(b)
    } else None
  }
  
  // returns true if bads is empty, meaning this wave is over
  def isOver = counter == villains.size
  
  /* returns true for the first 4 seconds of the wave
   * if true is returned, the wave number will be displayed in the gui
   */
  def displayWaveNo = (counter == 0) && (tmr > timeBetween - 4)

}