package hittable

/* represents all objects that can hit and get hit
 * all hittables have a finite ammount of healthPoints (hp)
 * if a hittable is hit, it looses some of its hp
 * if hp =< 0, the hittable is dead
 */
abstract class Hittable(healthPoints: Int) {
  
  val maxHp = healthPoints
  private var hpoints = maxHp
  private var dead = false
  
  def hp = hpoints
  
  // takes x hp and checks if the hittable is dead after this
  def takeHp(x: Int): Unit = {
    if(x < hp) {
      hpoints -= x
    } else {
      hpoints = 0
      dead = true
    }
  }
  
  // returns true if hp =< 0
  def isDead = dead
  
  // returns true if the hittable has lost some hp
  def isHurt = hp < maxHp
  
}