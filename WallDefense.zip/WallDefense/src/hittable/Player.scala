package hittable

/* represents the player of the game
 * the player is not physically present in the game 
 * initialMoney : how much money the player has when the level starts
 */
class Player(hp: Int, initialMoney: Int) extends Hittable(hp) {
  
  private var dallars = initialMoney
  
  // returns how much money the player has
  def money = dallars
  
  // gives the player x money
  def addMoney(x: Int) = {
    dallars += x
  }
  
  // takes x money from the player
  def takeMoney(x: Int): Boolean = {
    if(x <= dallars) {
      dallars -= x
      true
    } else false
  }
  
  /* kills the player, ending the game
   * is called when one of the walls is destroyed by the BadGuys
   */
  def kill = {
    takeHp(maxHp)
  }
  
  // returns a clone of the player
  override def clone = new Player(hp, initialMoney)
}