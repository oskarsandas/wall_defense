package hittable

/* represents a hittable barbed wire 
 * it can hit BadGuys and get hit by them
 */
class BarbWire extends Hittable(30) {
  val damage = 10
  val price = 100
  val interval = 0.5
  
  private var tmr = interval
  
  /* takes the interval (in seconds) between the previous and current frame
   * returns true every this.interval seconds
   * used to check if it should hit BadGuys standing next to it
   */
  def hitTimer(t: Double) = {
    tmr -= t
    if(0 >= tmr) {
      tmr = interval
      true
    } else false
  }
  
  // hits a BadGuy (b) I.e. takes this.damage hp from him
  def hit(b: BadGuy) = {
    b.takeHp(damage)
  }
}