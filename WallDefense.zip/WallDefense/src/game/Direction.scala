package game

/* represents a direction in which BadGuys can move in
 * each direction has a x-vector and y-vector
 */
sealed class Dir(val xV: Int, val yV: Int) {
  
  // returns the opposite of this direction
  def opposite = {
    this match {
      case N => S
      case E => W
      case S => N
      case W => E
      case _ => S
    }
  }
}
case object N extends Dir(0, -1)
case object E extends Dir(1, 0)
case object S extends Dir(0, 1)
case object W extends Dir(-1, 0)