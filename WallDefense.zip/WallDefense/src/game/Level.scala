package game
import block._
import hittable._
import scala.collection.mutable.Buffer

/* represents one level of the game
 * each level has its own blocks, player and waves
 */
class Level(val blocks: Array[Array[Block]], val player: Player, val waves: Array[Wave]) {
  
  def width = blocks(0).size * BlockSize.size
  def height = blocks.size * BlockSize.size
  
  // returns how many blocks wide the map is
  def rows = blocks.size
  
  // returns how many blocks high the map is
  def columns = blocks(0).size
  
  // a buffer containing all the BadGuys that the player can see I.e. all the BadGuys that have spawned and not yet died
  private var badGuysOnField = Buffer[BadGuy]()
  
  /* returns all BadGuys that have spawned and not yet died
   * if a BadGuy has died, the player will be given BadGuy.rewardIfKilled money
   * then the dead BadGuys will be removed from badGuysOnField
   */
  def badGuys = {
    badGuysOnField.filter(_.isDead).foreach(n => player.addMoney(n.rewardIfKilled))
    badGuysOnField = badGuysOnField.filter(!_.isDead)
    badGuysOnField
  }
  
  // spawns a BadGuy 
  def addBadGuy(b: BadGuy): Unit = {
    badGuysOnField += b
  }
  
  private var currentWaveNumber = 1
  def currentWave = waves(currentWaveNumber - 1)
  def currentWaveNo = currentWaveNumber
  
  // changes the current wave to i and returns true if successful
  def setWave(i: Int) = {
    if(i >= 1 && waves.size >= i) {
      currentWaveNumber = i
      true
    } else false
  }
  
  /* returns the block located at a given point
   * throws ArrayIndexOutOfBoundsException if the given point is outside the map
   */
  def blockAt(x: Int, y: Int): Block = {
      blocks(y / BlockSize.size)(x / BlockSize.size) 
  }
  
  /* returns an Option[Block] containing the neighboring block in direction (d) to a block at the given coordinates
   * x and y determine which blocks neighbor we are looking for
   * d determines in which direction the neighbor is, relative to the block
   */
  def neighborInDir(x: Int, y: Int, d: Dir): Option[Block] = {
    val col = x / BlockSize.size
    val row = y / BlockSize.size
    d match {
      case N => if(row == 0)           None else Some(blocks(row - 1)(col))
      case E => if(col == columns - 1) None else Some(blocks(row)(col + 1))
      case S => if(row == rows - 1)    None else Some(blocks(row + 1)(col))
      case W => if(col == 0)           None else Some(blocks(row)(col - 1))
      case _ => None
    }
  }
  
  /* returns 3 or less neighbors in direction d
   * consider following blocks (each 100 wide and high):
   * 
   *  123
   *  456
   *  789
   * 
   * neighborsInDir(150, 150, N) = Array((4, W), (2, N), (6, E)) "Block 5s neighbors in North are : 4 West, 2 North, 6 East"
   * neighborsInDir(10, 110, S) = Array((5, E), (7, S)) "Block 4s neighbors in South are : 5 East, 7 South"
   * neighborsInDir(200, 200, E) = Array() "Block 9 has no neighbors in East"
   */
  def neighborsInDir(x: Int, y: Int, d: Dir): Array[(Block, Dir)] = {
    val n = neighborInDir(x, y, N)
    val e = neighborInDir(x, y, E)
    val s = neighborInDir(x, y, S)
    val w = neighborInDir(x, y, W)
    d match {
      case N => Array((w, W), (n, N), (e, E)).filter(_._1.isDefined).map(n => (n._1.get, n._2))
      case E => Array((n, N), (e, E), (s, S)).filter(_._1.isDefined).map(n => (n._1.get, n._2))
      case S => Array((e, E), (s, S), (w, W)).filter(_._1.isDefined).map(n => (n._1.get, n._2))
      case W => Array((s, S), (w, W), (n, N)).filter(_._1.isDefined).map(n => (n._1.get, n._2))
      case _ => Array[(Block, Dir)]()
    }
  }
  
  // returns the direction in which the neighboring road is
  def roadInDir(x: Int, y: Int, d: Dir): Option[Dir] = {
    val neighbor = neighborsInDir(x, y, d).find(_._1.name == "Road")
    if(neighbor.isDefined) Some(neighbor.get._2)
    else None
  }
  
  // an Array of all spawn points
  val spawnPoints = blocks.flatten.filter(n => n.name == "Road" && n.asInstanceOf[Road].spawnPoint)
  private var pathsBuffer = Buffer[Path]()
  
  // finds a path starting from each spawn point and adds it to pathsBuffer
  for(s <- spawnPoints) {
    var dir: Dir = S
    var currentB: Block = s
    var points = Buffer[(Double, Double, Dir)]()
    var pathRead = false
    // if there is there are no roads in dir S, dir is changed to N
    if(!neighborInDir(s.x, s.y, dir).isDefined) {
      dir = dir.opposite
    }
    //adds the spawn point as the paths first point
    points += ( (s.middle._1, s.middle._2, roadInDir(s.x, s.y, dir).getOrElse(throw new NoSuchElementException("illegal path"))) )
    dir = roadInDir(s.x, s.y, dir).getOrElse(throw new NoSuchElementException("illegal path"))
    
    //adds all corners in the road to the path as points
    while(!pathRead) {
      val nextD = roadInDir(currentB.x, currentB.y, dir)
      var nextDir: Dir = null
      if(nextD.isDefined) {
        nextDir = nextD.get
        if(nextDir != dir) {
          dir = nextDir
          points += ((currentB.middle._1, currentB.middle._2, dir))
        }
        currentB = blockAt(currentB.x + dir.xV * BlockSize.size, currentB.y + dir.yV * BlockSize.size)
      } else if(neighborsInDir(currentB.x, currentB.y, dir).find(_._1.name == "Wall").isDefined) {
        pathRead = true
      } else {
        throw new NoSuchElementException("illegal path")
      }
    }
    pathsBuffer += new Path(points.toArray)
  }
  
  // Array containing this levels paths
  val paths = pathsBuffer.toArray
  
  // replaces the block at the given coordinates with a Road or Desert block, depending on the given blockType
  def setBlock(blockType: String, x: Int, y: Int) = {
    val col = x / BlockSize.size
    val row = y / BlockSize.size
    val block = {
      blockType match {
        case "Road" => new Road(x, y, false)
        case "Desert" => new Desert(x, y, false)
      }
    }
    blocks(row)(col) = block
  }
  
  // places the given weapon at its coordinates, replacing the block that was there before
  def setWeapon(wpn: Weapon) = {
    val col = wpn.x / BlockSize.size
    val row = wpn.y / BlockSize.size
    blocks(row)(col) = wpn.asInstanceOf[Block]
  }
  
  // sells a weapon, giving the player 50 % of the weapons buying price and placing Desert block at the weapons coordinates
  def sellWeapon(w: Weapon) = {
    setBlock("Desert", w.x, w.y)
    player.addMoney(w.price / 2)
  }
  
  val originalBlocks = blocks.clone()
  val originalPlayer = player.clone()
  val originalWaves = waves.clone()
  
  // returns a clone of the level
  override def clone = {
    new Level(originalBlocks, originalPlayer, originalWaves)
  }
  
}