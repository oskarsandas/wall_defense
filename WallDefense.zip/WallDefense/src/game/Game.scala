package game
import hittable._
import block._
import scala.collection.mutable.Buffer

/* represents the game 
 * each game is created based on the levels.txt file located in the res directory
 * each game contains levels, that have a map, waves of BadGuys and a player with a specified sum of money at the beginning
 * 
 */
class Game {
  // src : creates an Iterator containing the lines of the levels.txt file
  val src = io.Source.fromFile("res/levels.txt").getLines
  io.Source.fromFile("res/levels.txt").close()
  
  // line : contains the current line
  var line = src.next
  
  // currentLevelNumber contains the number of the current level, the game starts with level 1
  private var currentLevelNumber = 1
  
  // how many levels the game has, as indicated by the first line in the source file
  val numberOfLevels = line.trim().toLowerCase().dropWhile(_ != ':').drop(1).trim().toInt
  
  /* originalLevels : contains the levels that are read from the file, these are not changed in the game
   * when the state of the game is changed, these changes are done to a clone of the original levels
   */
  private val originalLevels = Array.ofDim[Level](numberOfLevels)
  
  // the time it takes for the next wave to start, when the current wave has ended
  private val timeBetweenWaves = 10.0
  
  def currentLevelNo = currentLevelNumber
  
  // reads one line of the source file
  def read = {
    line = src.next
  }
  
  /* removes the leading zero form a string containing numbers
   * E.g. removeZero("007") => "7"
   */
  def removeZero(s: String): String = s.replaceFirst("^0+(?!$)", "")
  
  /* creates a Block with given x and y coordinates based on the id
   * used when reading the map from the levels.txt file
   */
  def parseBlock(id: String, x: Int, y: Int): Block = {
    id match {
      case "0" => new Desert(x, y, false)
      case "1" => new WallBlock(x, y)
      case "2" => new Road(x, y, false)
      case "T" => new Desert(x, y, true)
      case "S" => new Road(x, y, true)
      case "#" => {
        val r = new Road(x, y, false)
        r.placeBarbWire
        r
      }
    }
  }
  
  /* creates a level with given number levelNo and adds it to this.originalLevels
   * each level starts with "#Level" and ends when the next next level starts or the file is read
   */
  def readLevel(levelNo: Int) = {
    read
    var bloccs = Buffer[Array[String]]()
    read
    val player = new Player(500, line.toInt)
    read
    read
    while(!(line startsWith "#wave")) {
      bloccs += line.split("")     
      read
    }
    val blocks = bloccs.toArray.map(_.zipWithIndex).zipWithIndex.map(a => a._1.map(b => parseBlock(b._1, b._2 * BlockSize.size, a._2 * BlockSize.size)))

    val waves = Buffer[Wave]()
    
    while(!(line startsWith "#end")) {
      read
      val timeBetween = line.toDouble
      val villains = Buffer[BadGuy]()
      read
      while(!(line startsWith "#wave") && !(line startsWith "#end")) {
        val times = removeZero(line.take(2)).toInt
        val damage = removeZero(line.drop(3).take(3)).toInt
        val reward = removeZero(line.drop(6).take(3)).toInt
        val hitrate = removeZero(line.drop(9).take(3)).toDouble
        val speed = removeZero(line.drop(12).take(3)).toInt
        val hp = removeZero(line.drop(15).take(3)).toInt
        for(n <- 0 until times) {
          villains += new BadGuy(damage, reward, hitrate, speed, hp)
        }
        read
      }
      waves += new Wave(villains.toArray, timeBetween)
    }
    
    originalLevels(levelNo - 1) = new Level(blocks, player, waves.toArray)
  }
  
  // reads all levels of the game and adds them to the game
  for(l <- 1 to numberOfLevels) {
    readLevel(l)
  }
  
  private var over = false
  
  /* returns a clone of the originalLevels
   * here the current state of the game is stored 
   */
  private var levelsClone = originalLevels.map(_.clone())
  
  // returns true if the last wave of the last level has been played
  def gameOver = over
  
  def levels = levelsClone
  
  /* changes the level to i
   * if there is no level i, the game is over, as indicated by the now true this.gameOver
   */
  def setLevel(i: Int): Unit = {
    if(i >= 1 && numberOfLevels >= i) {
      currentLevelNumber = i
      levelsClone = originalLevels.map(_.clone()) 
    } else {
      over = true
    }
  }
   
  // returns the currentLevel
  def currentLevel = levelsClone(currentLevelNo - 1)
  
  private var waveTmr = timeBetweenWaves
  private val r = new util.Random(System.nanoTime.toInt)
  
  /* takes the interval between this and the previous frame
   * calls the current waves timer
   * if the current waves timer returns a BadGuy, he is spawned with one of the levels paths randomly assigned to him
   * if the currentWave is over and this.timeBetweenWaves seconds have passed, the next wave starts
   * if there is no next wave, the first wave of the next level starts and if there is no next level, the game is over
   */
  def waveTimer(t: Double): Unit = {
    val l = currentLevel
    if(l.currentWave.isOver) {
      waveTmr -= t
      if(0 >= waveTmr) {
        if(!l.setWave(l.currentWaveNo + 1)) {
          setLevel(currentLevelNo + 1)
        }
        waveTmr = timeBetweenWaves
      }
    } else {
      val b = l.currentWave.timer(t)
      if(b.isDefined) {
        b.get.setPath(l.paths(r.nextInt(l.paths.size)).clone())
        l.addBadGuy(b.get)
      }
    }
  }
  
}