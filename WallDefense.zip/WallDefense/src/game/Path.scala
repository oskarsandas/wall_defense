package game

/* a path is the route BadGuys move on
 * each corner on road is a point on the path
 * the first point on the path is a spawn point on the map
 * each point contains the x and y coordinate of the corner blocks middle point and the direction in which the road continues from the corner  
 */
class Path(private val points: Array[(Double, Double, Dir)]) {
  private var current = 0
  private var pathRead = false
  
  def read = {
    pathRead
  }
  
  // returns the next point on the path
  def nextPoint = points(current)
  
  // reads the current point on the path
  def pointRead = {
    if(current == points.size - 1) {
      pathRead = true
    }
    else {
      current += 1
    }
  }
  
  // returns a clone of this path
  override def clone = {
    new Path(points)
  }
}