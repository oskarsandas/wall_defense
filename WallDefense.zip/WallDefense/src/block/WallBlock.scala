package block
import hittable.Wall
import hittable.BarbWire

/* represents a Wall block
 * each WallBlock has a hittable Wall object
 */
class WallBlock(x: Int, y: Int) extends Block(x, y) {
  private val hp: Int = 400
  val name = "Wall"
  
  // returns the hittable Wall object
  val wall = new Wall(hp)
  
  // returns Some(BarbWire) if this block has a barbWire 
  private var barbW: Option[BarbWire] = None
  
  // returns true if this block has a barbWire
  def hasBarbWire = {
    if(barbW.isDefined && barbW.get.isDead) {
      barbW = None
    }
    barbW.isDefined
  }
  
  // places a barbWire on this block
  def placeBarbWire = {
    barbW = Some(new BarbWire)
  }
  
  def barbWire = barbW
}