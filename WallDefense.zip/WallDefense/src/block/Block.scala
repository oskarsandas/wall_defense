package block

/* Represents one square on the ground. 
 * Each block has x and y coordinates, that point out the top left corner of the block.
 */

abstract class Block(val x: Int, val y: Int) {
  val width = BlockSize.size
  
  // name : tells which type of block it is (Road, Desert, Weapon, WallBlock)
  val name: String
  
  // middle :  returns a tuple containing the x and y coordinates of the blocks center
  def middle: (Double, Double) = {
    (x + width / 2.0, y + width / 2.0)
  }
  
}

/* provides the size of each block 
 * since blocks are squares size = height and size = width
 */
object BlockSize {
  val size = 100
}