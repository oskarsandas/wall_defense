package block
import hittable._

/* represents a block of road
 * spawnPoint : returns true if this block is a spawn point I.e. BadGuys can spawn on this block
 */
class Road(x: Int, y: Int, val spawnPoint: Boolean) extends Block(x, y){
  val name = "Road"
  
  // returns Some(BarbWire) if this block has a barbWire 
  private var barbW: Option[BarbWire] = None
  
  // returns true if this block has a barbWire
  def hasBarbWire = {
    if(barbW.isDefined && barbW.get.isDead) {
      barbW = None
    }
    barbW.isDefined
  }
  
  // places a barbWire on this block
  def placeBarbWire = {
    barbW = Some(new BarbWire)
  }
  
  def barbWire = barbW


}