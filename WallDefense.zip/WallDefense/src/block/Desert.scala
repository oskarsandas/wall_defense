package block

/* represents a block of desert 
 * trump : returns true if the player (Donald Trump) should be drawn in this block
 */
class Desert(x: Int, y: Int, val trump: Boolean) extends Block(x, y) {
  val name = "Desert"
}