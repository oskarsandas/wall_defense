package block
import hittable._

/* represents a block with a wepon on it
 * each weapon has a specific damage, hitrRate, range and price
 */
abstract class Weapon(x: Int, y: Int, val damage: Int, val hitRate: Double, val range: Double, val price: Int) extends Block(x, y) {
  val name = "Weapon"
  val weaponType: String
  
  /* returns the angle between this weapon (middle of the block) and a BadGuy (b)
   * the angle is rounded by 5
   * the angle is rounded differently based on the sign of the angle, this is done to better align the pipe of a soldiers rifle and the line that represents a bullets trajectory 
   */
  def getAngle(b: BadGuy) = {
    val a = Math.toDegrees(Math.atan2(this.middle._2 - b.y, b.x - this.middle._1))
    a match {
      case n if a < 0  || a > 175 => a - a % 5
      case p if a < 175 => a + 6 - (a + 6) % 5 
    }
  }
  // def hit, could be defined here, but I got an AssertionError (location Unknown), so hit is defined in every Weapon
}

/* represents Tesla coils that give an electric shock to all BadGuys within range
 */
class Zapper(x: Int, y: Int, damage: Int, hitRate: Double, range: Double, price: Int) extends Weapon(x, y, damage, hitRate, range, price) {
  val weaponType = "Zapper"
  private var interval = 1 / hitRate
  private var tmr = interval
  
  // returns true every this.interval seconds
  def hitTimer(t: Double) = {
    tmr -= t
    if(0 >= tmr) {
      tmr = interval
      true 
    } else false
  }
  
  def hit(b: BadGuy) = b.takeHp(damage)
  
  def clone(newX: Int, newY: Int) = {
    new Zapper(newX, newY, damage, hitRate, range, price)
  }
}

/* represents a nuclear weapon
 * when placed it does nothing, until it is detonated by calling detonate
 */
class Nuke(x: Int, y: Int, damage: Int, hitRate: Double, range: Double, price: Int) extends Weapon(x, y, damage, hitRate, range, price) {
  val weaponType = "Nuke"
  
  // boom : returns true if this.detonate has been called
  private var boom = false
  def detonated = boom
  
  // detonates the bomb
  def detonate = {
    boom = true
  }
  
  /* sizes : returns an Iterator of doubles, by which the explosion image is scaled
   * used to create the animation of the explosion
   */
  private val sizes = Iterator(0.25, 0.25, 0.5, 0.5, 0.5, 1, 1, 2, 2, 3, 3, 4, 4, 5)
  def fireSize = sizes.next()
  
  def hit(b: BadGuy) = b.takeHp(damage)
  
  def clone(newX: Int, newY: Int) = {
    new Nuke(newX, newY, damage, hitRate, range, price)
  }
}

/* represents a soldier
 * if there are BadGuys within the soldiers range it selects the "oldest" one I.e. the one that spawned first as its target
 * while the target is in range it shoots at it with this.hitrate
 * the first shot is shot after 0.4 seconds, after this they are shot every this.interval seconds, as long as the target stays the same
 */
class Soldier(x: Int, y: Int, damage: Int, hitRate: Double, range: Double, price: Int) extends Weapon(x, y, damage, hitRate, range, price) {
  val weaponType = "Soldier"
  private var interval = 1 / hitRate
  private var tmr = 0.4
  
  // the angle at which the soldier image is rotated I.e. the angle between the soldier and the target
  private var imgAngle = 0.0
  private var targetBadGuy: Option[BadGuy] = None 
  
  // sets the angle to a
  def setAngle(a: Double) = {
    imgAngle = a
  }
  
  // returns the angle
  def angle = imgAngle
  
  // returns true every this.interval seconds
  def hitTimer(t: Double) = {
    tmr -= t
    if(0 >= tmr) {
      tmr = interval
      true 
    } else false
  }
  
  // resets the timer to 0.4
  def resetTimer = {
    tmr = 0.4
  }
  
  def target: Option[BadGuy] = targetBadGuy
  
  // returns true if the target is defined and it is not dead
  def hasTarget = targetBadGuy.isDefined && !targetBadGuy.get.isDead
  
  // sets the target to b
  def setTarget(b: BadGuy) = {
    resetTimer
    targetBadGuy = Some(b)
  }
  
  def hit(b: BadGuy) = b.takeHp(damage)
  
  def clone(newX: Int, newY: Int) = {
    new Soldier(newX, newY, damage, hitRate, range, price)
  }
}