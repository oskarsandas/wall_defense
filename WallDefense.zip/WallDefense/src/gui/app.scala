package gui
import java.io.BufferedInputStream
import java.io.FileInputStream

import block._
import game._
import hittable._
import scalafx.Includes._
import scalafx.animation.AnimationTimer
import scalafx.application.JFXApp
import scalafx.event.ActionEvent
import scalafx.scene.Scene
import scalafx.scene.canvas.Canvas
import scalafx.scene.control.Menu
import scalafx.scene.control.MenuBar
import scalafx.scene.control.MenuItem
import scalafx.scene.image.Image
import scalafx.scene.input.MouseEvent
import scalafx.scene.layout.BorderPane
import scalafx.scene.paint.Color
import scala.collection.mutable.Buffer
import scalafx.scene.text._
import scalafx.scene.control.Button
import scalafx.scene.control.ToggleButton
import scalafx.scene.layout.AnchorPane
import scalafx.scene.layout.StackPane
import scalafx.scene.control.RadioButton
import scalafx.scene.control.ToggleGroup
import scalafx.scene.image.ImageView
import scalafx.scene.layout.Pane
import scalafx.scene.SnapshotParameters
import scalafx.geometry.Point3D
import scalafx.scene.transform.Rotate
import scalafx.scene.transform.Affine

object app extends JFXApp {

  var game = new Game
  val gunCanvasHeight = 100
  val gunCanvasWidth = 1400
  val menuHeight = 29
  def level = game.currentLevel
  val zapperRange = 2.5 * BlockSize.size
  
  // creates Imgaes of all the images in the res folder
  val trumpImg = new Image(new BufferedInputStream(new FileInputStream("res/Donald.png")), BlockSize.size, BlockSize.size, true, true)
  val wallImg = new Image(new BufferedInputStream(new FileInputStream("res/wall.png")), BlockSize.size, BlockSize.size, true, true)
  val mexicanImg = new Image(new BufferedInputStream(new FileInputStream("res/mexican.png")), BlockSize.size, BlockSize.size, true, true)
  val mexicanHitImg = new Image(new BufferedInputStream(new FileInputStream("res/mexicanHit.png")), BlockSize.size, BlockSize.size, true, true)
  val barbWireImg = new Image(new BufferedInputStream(new FileInputStream("res/barbWire.png")), BlockSize.size, BlockSize.size, false, true)
  val barbWireRedImg = new Image(new BufferedInputStream(new FileInputStream("res/barbWireRed.png")), BlockSize.size, BlockSize.size, false, true)
  val barbWireGreenImg = new Image(new BufferedInputStream(new FileInputStream("res/barbWireGreen.png")), BlockSize.size, BlockSize.size, false, true)
  val coinImg = new Image(new BufferedInputStream(new FileInputStream("res/coin.png")), BlockSize.size, BlockSize.size, true, true)
  val zapImg = new Image(new BufferedInputStream(new FileInputStream("res/zap1.png")), zapperRange * 2, zapperRange * 2, true, true)
  val zapperImg = new Image(new BufferedInputStream(new FileInputStream("res/zapper.png")), BlockSize.size, BlockSize.size, true, true)
  val zapperRedImg = new Image(new BufferedInputStream(new FileInputStream("res/zapperRed.png")), BlockSize.size, BlockSize.size, true, true)
  val zapperGreenImg = new Image(new BufferedInputStream(new FileInputStream("res/zapperGreen.png")), BlockSize.size, BlockSize.size, true, true)
  val nukeImg = new Image(new BufferedInputStream(new FileInputStream("res/nuke.png")), BlockSize.size, BlockSize.size, true, true)
  val nukeRedImg = new Image(new BufferedInputStream(new FileInputStream("res/nukeRed.png")), BlockSize.size, BlockSize.size, true, true)
  val nukeGreenImg = new Image(new BufferedInputStream(new FileInputStream("res/nukeGreen.png")), BlockSize.size, BlockSize.size, true, true)
  val nukeExplosionImg = new Image(new BufferedInputStream(new FileInputStream("res/nukeXplosion.png")), 628, 628, true, true)
  val sellImg = new Image(new BufferedInputStream(new FileInputStream("res/sell.png")), gunCanvasHeight * 2 - 20, gunCanvasHeight - 10, true, true)
  val soldierImg = new Image(new BufferedInputStream(new FileInputStream("res/soldier.png")), BlockSize.size, BlockSize.size, true, true)
  val soldierGreenImg = new Image(new BufferedInputStream(new FileInputStream("res/soldierGreen.png")), BlockSize.size, BlockSize.size, true, true)
  val soldierRedImg = new Image(new BufferedInputStream(new FileInputStream("res/soldierRed.png")), BlockSize.size, BlockSize.size, true, true)
  
  // rotatedSoldier(5) returns the soldierImg rotated by +5 degrees
  var rotatedSoldier = Map[Int, Image]()
  
  // creates a map, containing the soldier image rotated with 5 degree increments from -180 to 180 degrees
  for (a <- 0 to 180 by 5) {
    val soldierView = new ImageView(soldierImg)
    soldierView.rotate = -a
    val params = new SnapshotParameters
    params.fill = Color.Transparent
    rotatedSoldier += (a -> soldierView.snapshot(params, null).asInstanceOf[Image])
    soldierView.rotate = a
    rotatedSoldier += (-a -> soldierView.snapshot(params, null).asInstanceOf[Image])
  }
  
  /* the stats of the weapons in the game, changing these will change all weapons of the same type in the game
   * clones of these weapons are used in the game
   */
  val zapper = new Zapper(0, 0, 20, 1.0, zapperRange, 500)
  val nuke = new Nuke(0, 0, 1000, 1.0, 5000, 1000)
  val soldier = new Soldier(0, 0, 10, 1.0, BlockSize.size * 3.5, 300)
  val barbWire = new BarbWire
  
  val window = new JFXApp.PrimaryStage
  window.title = "Wall Defense"
  
  
  /* this method runs the whole game
   * it returns a scalaFx scene, that is displayed in the window
   * the scene contains all the buttons, layouts and the Animation timer
   */
  def makeScene(w: Double, h: Double): Scene = new Scene(w, h) {
    // the canvas is where the game field is drawn
    val canvas = new Canvas(this.width.value, level.height)
    // the mouseCanvas sits on top of the canvas and is used to display thing like the mouse animations and texts
    val mouseCanvas = new Canvas(this.width.value, level.height)
    val gc = canvas.graphicsContext2D
    val mGc = mouseCanvas.graphicsContext2D
    // the gunCanvas is below the canvas and this is where the players money and all the weapon buttons are displayed
    val gunCanvas = new Canvas(gunCanvasWidth, gunCanvasHeight)
    val gunGc = gunCanvas.graphicsContext2D
    
    // if the curren level is narrower than the gunCanvas, this image fills the empty space right of the game field
    val trömpImg = new Image(new BufferedInputStream(new FileInputStream("res/trömp.jpg")), level.height * 1920 / 1080.0, level.height, true, true)
    
    // stops the game and starts a new one, used when changing levels
    def restart = {
      timer.stop()
      game = new Game
    }
    
    // the menuBar contains the menu bar at the top of the window, this is where you can change levels, restart the current level or quit
    val menuBar = new MenuBar
    val menu = new Menu("Menu")
    menu.items = List(new MenuItem("Restart"), new MenuItem("Quit"))

    menu.items(1).onAction = (ae: ActionEvent) => {
      sys.exit(0)
    }

    menu.items(0).onAction = (ae: ActionEvent) => {
      val currentNo = game.currentLevelNo
      restart
      setLevel(currentNo)
    }

    val levelMenu = new Menu("Level")
    for (l <- 1 to game.numberOfLevels) {
      levelMenu.items += new MenuItem(l.toString)
    }

    def levelButtonAction(level: Int) = (ae: ActionEvent) => {
      restart
      setLevel(level)
    }

    for (l <- 0 until levelMenu.items.size) {
      levelMenu.items(l).setOnAction(levelButtonAction(l + 1))
    }

    menuBar.menus = List(menu, levelMenu)
    
    // creates the button for selling weapons
    val sellButton = new ToggleButton
    sellButton.accessibleText = "sell"
    sellButton.layoutX = (176 / 60.0) * gunCanvasHeight + 20
    val sellView = new ImageView(sellImg)
    sellButton.graphic = sellView
    
    // creates the button for buying barbed wire
    val barbWireButton = new ToggleButton
    barbWireButton.accessibleText = "barbWire"
    val barbView = new ImageView(barbWireImg)
    barbWireButton.graphic = barbView
    barbView.fitHeight = 90
    barbWireButton.layoutX = (176 / 60.0) * gunCanvasHeight + 20 + 210

    // creates a button for buying a soldier
    val soldierButton = new ToggleButton
    soldierButton.accessibleText = "soldier"
    val soldierButtonView = new ImageView(soldierImg)
    soldierButton.graphic = soldierButtonView
    soldierButtonView.fitHeight = 90
    soldierButton.layoutX = (176 / 60.0) * gunCanvasHeight + 20 + 210 + 130
    
    // creates a button for buying a zapper (Tesla coils)
    val zapperButton = new ToggleButton
    zapperButton.accessibleText = "zapper"
    val zapperView = new ImageView(zapperImg)
    zapperButton.graphic = zapperView
    zapperView.fitHeight = 90
    zapperButton.layoutX = (176 / 60.0) * gunCanvasHeight + 20 + 210 + 260

    // creates a button for buying a nuke
    val nukeButton = new ToggleButton
    nukeButton.accessibleText = "nuke"
    val nukeView = new ImageView(nukeImg)
    nukeButton.graphic = nukeView
    nukeView.fitHeight = 90
    nukeButton.layoutX = (176 / 60.0) * gunCanvasHeight + 20 + 210 + 390

    // displays a gray box containing a message or weapon stats, depending on which button the mouse cursor is on
    def mouseOnButton(b: ToggleButton) = (me: MouseEvent) => {
      mGc.clearRect(0, 0, level.width, level.height)
      val x = b.layoutX.value
      val y = level.height - 250
      mGc.fill = Color.rgb(128, 128, 128, 0.8)
      mGc.fillRect(x, y, 300, 250)
      mGc.font = new Font("Impact", 25)
      mGc.fill = Color.White
      val txt = {
        b.accessibleText.value match {
          case "sell"     => s"Sell your weapon to \nSaudi Arabia and get \n50 % of the original price !!"
          case "barbWire" => s"Weapon type :      Barbed Wire \nPrice :      ${barbWire.price} \nDamage :     ${barbWire.damage} \nHitrate :      ${1 / barbWire.interval} / s"
          case "zapper"   => s"Weapon type :      Tesla Coils \nPrice :      ${zapper.price} \nDamage :      ${zapper.damage} \nHitrate :        ${zapper.hitRate} / s \nRange :      ${zapper.range.toInt / BlockSize.size} Blocks"
          case "soldier"  => s"Weapon type :   Border Patrol \nPrice :       ${soldier.price} \nDamage :      ${soldier.damage} \nHitrate :      ${soldier.hitRate} / s \nRange :       ${soldier.range.toInt / BlockSize.size} Blocks"
          case "nuke"     => s"If nothing else works, . . .\nNUKE THE BORDER \nPRESS THAT RED BUTTON !!! \n\nPrice :          ${nuke.price} \nDamage :        ${nuke.damage} \n\nKlick the nuke, to detonate"
        }
      }
      mGc.fillText(txt, x, y + 25)
    }

    val buttons = List(sellButton, barbWireButton, soldierButton, zapperButton, nukeButton)
    // creates a toggle group I.e. just one of the buttons can be pressed at once
    val toggleGroup = new ToggleGroup
    toggleGroup.toggles = buttons

    for (b <- buttons) {
      b.setOnMouseEntered(mouseOnButton(b))
    }
    
    //the layout of the scene
    val mainStack = new StackPane
    mainStack.children = List(canvas, mouseCanvas)
    val gunStack = new StackPane
    val buttonPane = new Pane
    buttonPane.children = buttons
    gunStack.children = List(gunCanvas, buttonPane)
    val rootPane = new BorderPane
    rootPane.top = menuBar
    rootPane.center = mainStack
    rootPane.bottom = gunStack
    root = rootPane
    
    onMouseClicked = (me: MouseEvent) => {
      val x = me.x
      val y = me.y - menuHeight
      val block = level.blockAt(x.toInt, y.toInt)
      try {
        if (block.name == "Weapon" && block.asInstanceOf[Weapon].weaponType == "Nuke" && !block.asInstanceOf[Nuke].detonated) block.asInstanceOf[Nuke].detonate
        buttons.find(_.isSelected()).getOrElse(throw new NullPointerException).accessibleText.value match {
          case "zapper" => {
            if (block.name == "Desert" && !block.asInstanceOf[Desert].trump && level.player.takeMoney(zapper.price)) {
              level.setWeapon(zapper.clone(block.x, block.y))
            }
          }
          case "barbWire" => {
            if (block.name == "Road" && !block.asInstanceOf[Road].hasBarbWire && level.player.takeMoney(barbWire.price)) {
              block.asInstanceOf[Road].placeBarbWire
            } else if (block.name == "Wall" && !block.asInstanceOf[WallBlock].hasBarbWire && level.player.takeMoney(barbWire.price)) {
              block.asInstanceOf[WallBlock].placeBarbWire
            }
          }
          case "sell" => {
            if (block.name == "Weapon") {
              level.sellWeapon(block.asInstanceOf[Weapon])
            }
          }
          case "nuke" => {
            if (block.name == "Desert" && !block.asInstanceOf[Desert].trump && level.player.takeMoney(nuke.price)) {
              level.setWeapon(nuke.clone(block.x, block.y))
            }
          }
          case "soldier" => {
            if (block.name == "Desert" && !block.asInstanceOf[Desert].trump && level.player.takeMoney(soldier.price)) {
              level.setWeapon(soldier.clone(block.x, block.y))
            }
          }
        }

      } catch {
        case e: NullPointerException =>
      }
    }

    onMouseMoved = (me: MouseEvent) => {
      val x = me.x
      val y = me.y - menuHeight
      mGc.clearRect(0, 0, level.width, level.height)
      def notEnoughMoney(p: Int) = {
        if(level.player.money < p) {
          mGc.font = new Font("Impact", BlockSize.size / 3)
          mGc.fill = Color.Black
          mGc.fillText("NOT ENOUGH MONEY", x, y)
        }
      }
      if (mouseCanvas.contains(x, y)) {
        val block = level.blockAt(x.toInt, y.toInt)
        if (block.name == "Weapon" && block.asInstanceOf[Weapon].weaponType == "Nuke") {
          mGc.font = new Font("Impact", BlockSize.size / 3)
          mGc.fill = Color.Red
          mGc.fillText("DETONATE", x, y)
        } else {
          try {
            buttons.find(_.isSelected()).getOrElse(throw new NullPointerException).accessibleText.value match {
              case "zapper" => {
                if (block.name == "Desert" && !block.asInstanceOf[Desert].trump) mGc.drawImage(zapperGreenImg, block.x, block.y)
                else mGc.drawImage(zapperRedImg, block.x, block.y)
                notEnoughMoney(zapper.price)
              }
              case "barbWire" => {
                if ((block.name == "Road" && !block.asInstanceOf[Road].hasBarbWire) || (block.name == "Wall" && !block.asInstanceOf[WallBlock].hasBarbWire)) mGc.drawImage(barbWireGreenImg, block.x, block.y)
                else mGc.drawImage(barbWireRedImg, block.x, block.y)
                notEnoughMoney(barbWire.price)
              }
              case "nuke" => {
                if (block.name == "Desert" && !block.asInstanceOf[Desert].trump) mGc.drawImage(nukeGreenImg, block.x, block.y)
                else mGc.drawImage(nukeRedImg, block.x, block.y)
                notEnoughMoney(nuke.price)
              }
              case "soldier" => {
                if (block.name == "Desert" && !block.asInstanceOf[Desert].trump) mGc.drawImage(soldierGreenImg, block.x, block.y)
                else mGc.drawImage(soldierRedImg, block.x, block.y)
                notEnoughMoney(soldier.price)
              }
              case _ =>
            }

          } catch {
            case e: NullPointerException =>
          }
        }

      }
    }

    mouseCanvas.onMouseExited = (me: MouseEvent) => {
      mGc.clearRect(0, 0, level.width, level.height)
    }

    // draws the coin image on the gun canvas
    gunGc.fill = Color.rgb(255, 234, 144)
    gunGc.fillRect(0, 0, Math.max(level.width, gunCanvasWidth), gunCanvasHeight)
    gunGc.drawImage(coinImg, gunCanvasHeight / 6, gunCanvasHeight / 6, gunCanvasHeight / 1.5, gunCanvasHeight / 1.5)

    // draws the hp bar for a BadGuy, BarbWire or Wall, the position of the bar depends on the type of object the bar is drawn to
    def drawHpBar(x: Double, y: Double, blockType: String, hp: Int, maxHp: Int) = {
      val green = hp.toDouble / maxHp
      val width = BlockSize.size / 2.0
      val height = width / 5
      val xR = x - width / 2
      val yR = {
        blockType match {
          case "BadGuy" => y - 1.5 * width
          case "Barb"   => y - height
          case "Wall"   => y + height
        }
      }
      gc.fill = Color.rgb(246, 36, 36, 0.6)
      gc.fillRect(xR, yR, width * (1 - green), height)
      gc.fill = Color.rgb(88, 245, 49, 0.7)
      gc.fillRect(xR + width * (1 - green), yR, width * green, height)
    }

    // draws a desert block
    def drawDesert(b: Block) = {
      gc.fill = Color.rgb(255, 199, 100)
      gc.fillRect(b.x, b.y, b.width, b.width)
    }
 
    // keeps track of the last frame
    var lastTime = 0L

    /* the animationTimer is used to keep track of time, it takes as an input the current time
     * it draws the current state of the game on the different canvases and it changes the state of the game according to the users interactions
     * max fps = 60
     */
    val timer: AnimationTimer = AnimationTimer { time =>
      // the interval between this and the last frame, in seconds
      val interval = (time - lastTime) / 1e9

      /* the first "run" of the animationTimer nothing is done, except for setting this.lastTime to the current time
       * if we don't do this, the first interval would be too big
       */
      if (lastTime != 0) {
        // first the road, desert and wall blocks are drawn
        for (row <- 0 until level.blocks.size)
          for (col <- 0 until level.blocks(0).size) {
            val currentBlock = level.blocks(row)(col)
            currentBlock.name match {
              case "Desert" => {
                if (currentBlock.asInstanceOf[Desert].trump && !level.player.isDead) {
                  drawDesert(currentBlock)
                  gc.drawImage(trumpImg, currentBlock.x, currentBlock.y)
                } else drawDesert(currentBlock)
              }
              case "Wall" => {
                val w = currentBlock.asInstanceOf[WallBlock]
                if (!w.wall.isDead) {
                  gc.drawImage(wallImg, currentBlock.x, currentBlock.y)
                  if (w.wall.isHurt) {
                    drawHpBar(w.x + w.width / 2, w.y + w.width / 2, "Wall", w.wall.hp, w.wall.maxHp)
                  }
                  if (w.hasBarbWire) {
                    gc.drawImage(barbWireImg, currentBlock.x, currentBlock.y)
                    if (w.barbWire.get.isHurt) {
                      drawHpBar(w.x + w.width / 2, w.y + w.width / 2, "Barb", w.barbWire.get.hp, w.barbWire.get.maxHp)
                    }
                  }
                } else {
                  drawDesert(currentBlock)
                  level.player.kill
                }
              }
              case "Road" => {
                val r = currentBlock.asInstanceOf[Road]
                gc.fill = Color.rgb(223, 173, 87)
                gc.fillRect(currentBlock.x, currentBlock.y, currentBlock.width, currentBlock.width)
                if (r.hasBarbWire) {
                  gc.drawImage(barbWireImg, currentBlock.x, currentBlock.y)
                  if (r.barbWire.get.isHurt) {
                    drawHpBar(r.x + r.width / 2, r.y + r.width / 2, "Barb", r.barbWire.get.hp, r.barbWire.get.maxHp)
                  }
                }
              }
              case "Weapon" => {
                drawDesert(currentBlock)
              }
            }
          }

        def wiresRoad = level.blocks.flatten.filter(n => n.name == "Road" && n.asInstanceOf[Road].hasBarbWire)
        def wiresWall = level.blocks.flatten.filter(n => n.name == "Wall" && n.asInstanceOf[WallBlock].hasBarbWire)
        def walls = level.blocks.flatten.filter(n => n.name == "Wall")
        def wireBlocks = wiresRoad ++ wiresWall
        def hittableBlocks = wireBlocks ++ walls

        // all the badGuys are moved according to their path, if they are next to a Wall or barbed wire and their hitTimer retunrs true, they hit the hittable in front of them
        for (b <- level.badGuys) {
          val x = b.x
          val y = b.y
          val p = b.nextPoint
          val px = p._1
          val py = p._2
          val pdir = p._3
          val isInMiddle = Math.abs(x - level.blockAt(x.toInt, y.toInt).middle._1) < 3 && Math.abs(y - level.blockAt(x.toInt, y.toInt).middle._2) < 3

          if (!b.pathRead && Math.abs(x - px) < 3 && Math.abs(y - py) < 3) {
            b.setDir(pdir)
            b.setX(px)
            b.setY(py)
            b.pointRead
          } else if (isInMiddle && level.neighborsInDir(x.toInt, y.toInt, b.dir).find(_._1.name == "Road").isDefined && !level.neighborInDir(x.toInt, y.toInt, b.dir).get.asInstanceOf[Road].hasBarbWire) {
            b.setX(x + b.dir.xV * b.speed * interval)
            b.setY(y + b.dir.yV * b.speed * interval)
          } else if (!isInMiddle) {
            b.setX(x + b.dir.xV * b.speed * interval)
            b.setY(y + b.dir.yV * b.speed * interval)
          } else if (b.hitTimer(interval)) {
            val w = hittableBlocks.filter(n => Math.hypot(n.middle._1 - x, n.middle._2 - y) < 1.1 * BlockSize.size)
            w.foreach(b.hit(_))
            gc.fill = Color.rgb(255, 255, 255, 0.5)
            w.foreach(n => gc.fillRect(n.x, n.y, n.width, n.width))
          }
          gc.drawImage(mexicanImg, b.x - mexicanImg.width.value / 2, b.y - mexicanImg.height.value / 2)
          if (b.isHurt) drawHpBar(b.x, b.y, "BadGuy", b.hp, b.maxHp)
        }

        // all barbWires hitTimers are called, and they hit all badGuys next to them if the timer retuns true
        for (w <- wireBlocks) {
          val bads = level.badGuys.filter(b => Math.hypot(w.middle._1 - b.x, w.middle._2 - b.y) < 1.1 * BlockSize.size)
          w.name match {
            case "Road" => {
              val barb = w.asInstanceOf[Road].barbWire.get
              if (barb.hitTimer(interval)) {
                bads.foreach(barb.hit(_))
                bads.foreach(n => gc.drawImage(mexicanHitImg, n.x - mexicanHitImg.width.value / 2, n.y - mexicanHitImg.height.value / 2))
              }
            }
            case "Wall" => {
              val barb = w.asInstanceOf[WallBlock].barbWire.get
              if (barb.hitTimer(interval)) {
                bads.foreach(barb.hit(_))
                bads.foreach(n => gc.drawImage(mexicanHitImg, n.x - mexicanHitImg.width.value / 2, n.y - mexicanHitImg.height.value / 2))
              }
            }
          }
        }

        //all weapons are drawn and their timers are called
        for (block <- level.blocks.flatten.filter(_.name == "Weapon")) {
          val w = block.asInstanceOf[Weapon]
          w.weaponType match {
            case "Zapper" => {
              val z = w.asInstanceOf[Zapper]
              val bads = level.badGuys.filter(b => Math.hypot(w.middle._1 - b.x, w.middle._2 - b.y) <= z.range)
              gc.drawImage(zapperImg, z.x, z.y)
              if (z.hitTimer(interval) && !bads.isEmpty) {
                bads.foreach(z.hit(_))
                gc.drawImage(zapImg, z.x - z.range + BlockSize.size / 2, z.y - z.range + BlockSize.size / 2)
              }

            }
            case "Nuke" => {
              val n = w.asInstanceOf[Nuke]
              gc.drawImage(nukeImg, n.x, n.y)
            }
            case "Soldier" => {
              val s = w.asInstanceOf[Soldier]
              val bads = level.badGuys.filter(b => Math.hypot(w.middle._1 - b.x, w.middle._2 - b.y) <= s.range)
              if (s.hasTarget && bads.contains(s.target.get)) {
                if (s.hitTimer(interval)) {
                  val target = s.target.get
                  s.hit(target)
                  gc.drawImage(mexicanHitImg, target.x - mexicanHitImg.width.value / 2, target.y - mexicanHitImg.height.value / 2)
                  gc.stroke = Color.DarkRed
                  gc.lineWidth = 1
                  gc.strokeLine(s.middle._1, s.middle._2, target.x, target.y)
                }
                s.setAngle(s.getAngle(s.target.get))
              } else if (!bads.isEmpty) {
                s.setTarget(bads.head)
                s.hitTimer(interval)
                s.hit(s.target.get)
                s.setAngle(s.getAngle(s.target.get))
              }
              val sImg = rotatedSoldier(s.angle.toInt)
              gc.drawImage(sImg, s.middle._1 - sImg.width.value / 2, s.middle._2 - sImg.height.value / 2)
            }
          }
        }

        // animating the detonated nukes explosion
        val detonatedNukes = level.blocks.flatten.filter(n => n.name == "Weapon" && n.asInstanceOf[Weapon].weaponType == "Nuke" && n.asInstanceOf[Nuke].detonated)
        if (!detonatedNukes.isEmpty) {
          for (n <- detonatedNukes.map(_.asInstanceOf[Nuke])) {
            level.badGuys.foreach(n.hit(_))
            val scale = n.fireSize
            val size = nukeExplosionImg.width.value * scale
            gc.drawImage(nukeExplosionImg, n.x - size / 2, n.y - size / 2, size, size)
            if (scale == 5) {
              level.setBlock("Desert", n.x, n.y)
            }
          }
        }

        // if the gunCanvas is wider than the current level, the filler image is drawn on the right side
        if (gunCanvasWidth > level.width) mGc.drawImage(trömpImg, level.blocks(0).last.x + BlockSize.size, 0)

        // the players money is drawn
        gunGc.font = new Font("Impact", gunCanvasHeight / 1.5)
        gunGc.fill = Color.rgb(255, 234, 144)
        gunGc.fillRect(gunCanvasHeight - 10, 0, 2.5 * gunCanvasHeight, gunCanvasHeight)
        gunGc.fill = Color.DARKGOLDENROD
        gunGc.fillText(level.player.money.toString, gunCanvasHeight - 5, 3 * gunCanvasHeight / 4.0)

        // the games waveTimer is called
        game.waveTimer(interval)
      }
      
      // if the currentWave has started under 4 seconds ago, the current wave number is displayed
      if (level.currentWave.displayWaveNo) {
        gc.font = new Font("Impact", level.width / 5)
        gc.fill = Color.rgb(100, 0, 0, 0.7)
        gc.fillText(s"Wave ${level.currentWaveNo}", level.width / 5, level.height / 1.6)
      }

      // the time of the last frame is set to the current time => time moves on in the game
      lastTime = time
      
      // if game is lost / won => game over / game won message is drawn and the timer is stopped
      if (level.player.isDead) {
        gc.font = new Font("Impact", level.width / 5)
        gc.fill = Color.Black
        gc.fillText("Game Over", level.width / 15, level.height / 2)
        timer.stop()
      } else if (game.gameOver && level.badGuys.isEmpty) {
        gc.font = new Font("Impact", level.width / 8)
        gc.fill = Color.rgb(206, 22, 22, 0.95)
        gc.fillText(
          """America is great 
             again!!""", level.width / 17, level.height / 2)
        timer.stop()
      }

    }
    // the timer is started at the beginning of the game
    timer.start()

  }

  // changes the current level to i and replaces the current scene with the new one
  def setLevel(i: Int) = {
    game.setLevel(i)
    window.scene = makeScene(Math.max(level.width, gunCanvasWidth), level.height + gunCanvasHeight + menuHeight)
  }

  // game starts at level 1
  setLevel(1)
}